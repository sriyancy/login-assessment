
import { Component, ComponentFactoryResolver, OnInit, ViewContainerRef } from '@angular/core';
import {Router}  from '@angular/router'
import { DatalistService } from '../services/datalist.service';
import {AuthenticateService} from '../services/authenticate.service'
//import books from '../services/books.json'
import {CatalogService} from '../services/catalog.service'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  items1 = this._serv.datas;
  nomatch: boolean = false;
  books: any[] = [];
  // booksList: { _id: number; title: string }[] = books;
  title: String = '';
  public data1 = '';
  constructor(
    private router: Router,
    private _serv: DatalistService,
    private _auth: AuthenticateService,
    private cs: CatalogService
  ) {
    console.log(' home constuctor loaded');
  }

  count: number = 0;
  temp = [];
  ngOnInit(): void {
    this._auth.on<string>().subscribe((data) => {
      this.data1 = data;
    });
  }

  searchbyTitle() {
    this.cs
      .getBooksByTitle(this.title)
      .subscribe((books) => (this.books = books));
    this.nomatch = false;
    if (this.books.length == 0) this.nomatch = true;
    else {
      this.nomatch = false;
    }
  }

  logout() {
    console.log('logout');
    localStorage.clear();
    this.router.navigate(['/login'], { queryParams: {} });
  }
}
