import { Component } from '@angular/core';
import { DatalistService } from './services/datalist.service';
//import { AuthenticateService } from './authenticate.service';
//import {LocalStorageService} from 'ngx-webstorage'
//import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'login';

  constructor(private _service:DatalistService){
    console.log("app constructor loaded")
  }
// details(){
//   this._service.sendMessage("hi");
// }

}
