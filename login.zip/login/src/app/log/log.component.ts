import { Component, OnInit } from '@angular/core';
import {FormBuilder} from '@angular/forms'
import {AuthenticateService} from '../services/authenticate.service'
import {Router}  from '@angular/router'

@Component({

  selector: 'app-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.css']
})
export class LogComponent implements OnInit {
  
  
  
  log=this.fb.group({
   name:[''],
  password:['']
  
});



  constructor(private fb:FormBuilder,private _auth:AuthenticateService,private router:Router) { 
    console.log("log cinstructor loaded")
  } 

  ngOnInit(): void {
  }
  call(){
    this._auth.emit<string>(this.log.value['name']);
    
    console.log(this.log.value);
     this._auth.login(this.log.value)
    .subscribe(
      res=>{
         console.log(res)
         console.log(this.log.value['name'])
         localStorage.setItem('token',res)
          this.router.navigate(['/home']);
      
      },
      err=>console.log(err)
    )
  }
 // get details from server
  getDetails(){
    this._auth.get()
    .subscribe(
      res=>{
         console.log(res)
         
      },
      err=>{console.log(err)}
    )
  }


  
 

}
