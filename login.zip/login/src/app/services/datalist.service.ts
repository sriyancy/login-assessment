import { Injectable } from '@angular/core';
import { from} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DatalistService {
  datas=['one','two','three','four','five','six','seven','eight','nine','ten','eleven']
 // private _dataSource=new Subject<string>();
 // dataMessage$=this._dataSource.asObservable();
  constructor() { }
  // sendMessage(message:string){
  //   this._dataSource.next(message);

  // }
  btnClick(){
    from(this.datas).subscribe((a)=>{
      console.log(a);
    })
  }
 
}
