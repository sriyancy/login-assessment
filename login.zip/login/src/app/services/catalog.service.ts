import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs'
@Injectable({
  providedIn: 'root',
})
export class CatalogService {
 
  constructor(private http: HttpClient) {}
  getBooksByTitle(title: String): Observable<any> {
    return this.http.get(`http://localhost:4000/search/title/${title}`);
  }

  // getBooksByTitle(title: String) {
  //   return this.http.get(this._url, title, {
  //     responseType: 'text',
  //   });
  // }
}
