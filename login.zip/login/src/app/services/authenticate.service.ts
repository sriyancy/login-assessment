import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { BehaviorSubject ,Observable} from 'rxjs';
//import {} from '../app/log/log.component'
//import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthenticateService {
  private _url='http://localhost:4000/users/login'
  private _url1='http://localhost:4000/users'
 constructor(private http:HttpClient) { }
  login(user:any){
    return this.http.post(this._url,user, {
      responseType: 'text',
    })
  }
  //server get details
  get(){
    return this.http.get(this._url1)
  }
  loggedIn(){
    return !!localStorage.getItem('token')
  }
  public _subject=new BehaviorSubject<any>('')
  emit<T>(data:T){
    this._subject.next(data)
  }
  on<T>():Observable<T>{
    return this._subject.asObservable();
  }
 
}
