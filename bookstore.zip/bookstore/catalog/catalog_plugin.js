function catalog(option) {
	let books = [];

	this.add({ role: 'search', op: 'bytitle' }, (args, reply) => {
		const result = books.filter((book) => book.title == args.title); //take cal back pass empyty or aray
		reply(null, { result: result }); //callback method take two arg one is err/null n result->array ,obj
	});
	this.add({ init: 'catalog' }, (msg, reply) => {
		console.log('Catalog Plugin loaded');
		books = require('./books.json');
		// console.log(books);
		reply();
	});
	//serach by category
	this.add({ role: 'search', op: 'bycategory' }, (args, reply) => {
		const result = books.filter((book) => book.category == args.category); //take cal back pass empyty or aray
		reply(null, { result: result }); //callback method take two arg one is err/null n result->array ,obj
	});
	//serach by rating-excellent>=4.5 goog>=4 average <4
	this.add({ role: 'search', op: 'byrating' }, (args, reply) => {
		let result = '';
		if (args.rating == 'excellent') {
			result = books.filter((book) => book.rating >= 4.5);
		} //take cal back pass empyty or aray
		else if (args.rating == 'good') {
			result = books.filter(
				(book) => book.rating <= 4.5 && book.rating >= 4
			);
		} else if (args.rating == 'average') {
			result = books.filter((book) => book.rating < 4);
		}
		reply(null, { result: result }); //callback method take two arg one is err/null n result->array ,obj
	});
	this.add({ role: 'search', op: 'bycategoryrating' }, (args, reply) => {
		let result = '';
		this.act(
			{ role: 'search', op: 'byrating', rating: args.rating },
			(err, res) => {
				const booksbyrating = res.result;
				const result = booksbyrating.filter(
					(book) => book.category == args.category
				);
				reply(null, { result: result });
			}
		);
	});
	this.add({ role: 'catalog', op: 'view' }, (args, reply) => {
		const book = this.make('cart');
		book.list$({}, (err, books) => {
			if (err) return console.log(err);
			reply(null, { result: books });
		});
	});
}
module.exports = catalog;
