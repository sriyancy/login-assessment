 //const math_plug = require('./math_plug');
const seneca = require('seneca')({log:'silent'});//thhis can also be given
//seneca.quiet();//to remove other unnecessary log details
seneca.use("catalog_plugin");
console.log("seneca id :"+seneca.id);
//senca is a msged based microservices
//act must be in express app
// seneca.act({role:"search",op:"bytitle",title:"Unlocking Android"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });//invoking
// seneca.act({role:"search",op:"bytitle",title:"Android"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });

// seneca.act({role:"search",op:"byrating",rating:"average"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });
// seneca.act({role:"search",op:"byrating",rating:"excellent"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log("EXCELLENT",res);
//     }
// });
// seneca.act({role:"search",op:"bycategory",category:"Mobile"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });
// seneca.act({role:"search",op:"bycategory",category:"Java"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });
// seneca.act({role:"search",op:"bycategoryrating"},(err,res)=>{
//     if(err){
//         console.log("error"+err);
//     }
//     else{
//         console.log(res);
//     }
// });

seneca.listen(6789);
//to check in browaer by default-http://localhost:10101/act?component=math&op=add&a=10&b=20
//http://localhost:6789/act?role=search&op=bytitle&title=Unlocking%20Android