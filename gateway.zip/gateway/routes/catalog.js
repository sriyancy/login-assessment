var express = require('express');
var router = express.Router();
var seneca = require('seneca')();
/* GET users listing. */
seneca.client(6789); //create client host name
router.get('/title/:title', function (req, res, next) {
	//  res.send('respond with a resource');
	seneca.act(
		{ role: 'search', op: 'bytitle', title: req.params.title },
		(err, reply) => {
			if (err) {
				console.log('error occured');
			} else {
				res.send(reply.result);
			}
		}
	);
});

module.exports = router;
