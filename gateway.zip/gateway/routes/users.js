var express = require('express');
const jwt = require('jsonwebtoken');
var mongoClient = require('mongodb').MongoClient;
var router = express.Router();

/* GET users listing. */
router.get('/', function (req, res, next) {
	mongoClient.connect('mongodb://localhost:27017', (err, out) => {
		if (err) throw console.log('cannot connect to db', err);
		const db = out.db('activity1');
		const collection = db.collection('users');
		collection.find().toArray((err, doc) => {
			if (err) throw console.log('cannot connect to collection', err);
			res.send(doc);
		});
	});
	// res.send('respond with a resource');
});
router.post('/register', function (req, res, next) {
	const { name, email, userid, password } = req.body;
	mongoClient.connect('mongodb://localhost:27017', (err, out) => {
		if (err) throw console.log('cannot connect to db', err);
		const db = out.db('activity1');
		const collection = db.collection('users');

		collection.find({ name: req.body.name }).toArray((err, doc) => {
			if (err) throw err;
			console.log(req.body.name);
			console.log(doc.length);
			if (doc.length == 0) {
				collection.insertOne(
					{ name, email, userid, password },
					(err, doc) => {
						if (err)
							throw console.log('cannot connect to collection', err);

						res.send('done');
					}
				);
			}
			if (doc.length != 0) {
				console.log('false');
				res.send(doc);
			}
		});
	});
	// res.send('respond with a resource');
});
router.post('/login', function (req, res, next) {
	mongoClient.connect('mongodb://localhost:27017', (err, out) => {
		if (err) throw console.log('cannot connect to db', err);
		const db = out.db('activity1');
		const collection = db.collection('users');

		collection.find({ name: req.body.name }).toArray((err, doc) => {
			if (err) throw console.log('cannot connect to collection', err);

			if (doc[0].password == req.body.password) {
				let payload = { subject: req.body.name };
				let token = jwt.sign(payload,'secretKey');
				console.log('success');
				
				res.send(token );
			}
			//  else {
			// 	console.log('failure');
			// 	res.send('failure');
			// }
		});
	});
});

module.exports = router;
